import SwiftUI
import RealityKit
struct ContentView: View {
    @State var isPaused = true
    var body: some View {
        ZStack {
            ARViewContainer(isPaused: $isPaused)
                .ignoresSafeArea()
            VStack {
                Spacer()
                Button(isPaused ? "Stop" : "Play") {
                    self.isPaused.toggle()
                }
                .padding()
                .background(.red)
                .cornerRadius(10, antialiased: true)
                .padding()
            }
        }
    }
}
struct ARViewContainer: UIViewRepresentable {
    @Binding var isPaused: Bool
    @State var someAnimation: [AnimationPlaybackController] = []
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        let anchorEntity = AnchorEntity(plane: .horizontal)
         let modelEntity = try! ModelEntity.load(named: "toy_biplane_idle") 
        anchorEntity.addChild(modelEntity)
        arView.scene.addAnchor(anchorEntity)
        return arView
    }
    func updateUIView(_ uiView: ARView, context: Context) {
        if isPaused {
            uiView.scene.anchors[0].children[0].stopAllAnimations(recursive: true)
        } else {
            let modelEntity = try! ModelEntity.load(named: "toy_biplane_idle") 
            let someAnimation = modelEntity.availableAnimations[0].repeat(count: .max)//删除.repeat(count: .max);改 .max为3
            uiView.scene.anchors[0].children[0].playAnimation(someAnimation, transitionDuration: 1.0, startsPaused: false)
        }
    }
}

